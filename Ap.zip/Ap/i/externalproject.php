<?php

?>

<! DOCTYPE html>
<html>

 <head>
      <title>Ticket</title>
	  <link rel="stylesheet" href="css/stylex.css" type="text/css">
	  <style>
	div 
	{
		
		background:url(sa.png);
		background-position: center;
		background-repeat: no-repeat;
	
	
		
	}
	</style>

 </head>
<body background="C:\Users\3csea19\Desktop\train.jpg">
<form class="myform" action="externalproject.php" method="post">
<div class="grid">
  <center>
   <h1 style="color: border-radius:30px;"><b>Plan My Travel and Book Ticket</b></h1>
</center>
<div>
<h3>
<form action="">&nbsp

      From: &nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="From" value="Delhi(DLI)"></input><br>&nbsp
      To:&nbsp&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp <input type="text" name="To" value="BCI"></input><br>&nbsp
     Date: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<select>
            <option value="02">02</option>
         </select>
         <select>
             <option value="Jul">Jul</option>
        </select>
        <select>
             <option value="2007">2007</option>
       </select><br>&nbsp
Class:&nbsp&nbsp&nbsp&nbsp&nbsp
        <select>
           <option value="AC 2-tier sleeper(2A)">AC 2-tier sleeper(2A)</option>
        </select><br>&nbsp
Tatkal type: &nbsp&nbsp&nbsp&nbsp&nbsp<input type="radio" name="chooseone">i-ticket  ?</input>
                  <input type="radio" name="chooseone"  >e-ticket  ?</input><br>
                   &nbsp&nbsp&nbsp&nbsp<input type="checkbox" name="Tatkal" value="Tatkal">&nbsp Tatkal  ?</input>
				   
<center>
       <input type="button"  value="Go"></input>
       &nbsp&nbsp  &nbsp&nbsp&nbsp&nbsp&nbsp
      <input type="button"  value="Reset"></input>
      <h5 align="left">Now Get Back <br><br> Upto 10% of your AC ticket fare <br><br>As railway Points with Shubb Yatra</h5><br><br>
     <a href="sample.html">Apply now </a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp
     <a href="sample.html">Know more </a>
     <h4>To get Shubb Yatra Benefits on this ticket</h4>
     <h4>About Shubb Yatra</h4><br>
</center>

</form>
</h3>
</div>
     

</div>
</form>
</body>
</html>