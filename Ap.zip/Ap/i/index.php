<?php
	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Login page</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#bdc3c7">

<div id="main-wrapper">
     <center>
	     <h2 >L o g i n &nbsp F o r m</h2>
		 <img src="imgs/sa.png" class="avatar"/>
	</center>
	
	<form class="myform" action="timer.html" method="post">
	     <h3><label><b>U s e r n a m e :</b></label><br><br>
		 <input name="username"type="text"  class="inputvalues" placeholder="E n t e r   U s e r n a m e" required/><br><br>
		 <label><b>P a s s w o r d :</b></label><br><br>
		 <input name="password" type="password"  class="inputvalues" placeholder="E n t e r   P a s s w o r d" required/></h3><br>
		 <center><input name="login" type="submit" id="login_btn" value="L o g i n"/><br><br>
		<a href=register.php><input type="button" id="register_btn" value="R e g i s t e r"/></a></center>
	 </form>
	 <?php
		if(isset($_POST['login']))
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
			
			$query=" select * from user WHERE username= '$username' AND password= '$password' ";
			$query_run = mysqli_query($con,$query);
			if(mysqli_num_rows($query_run)>0)
				{
					
				}
			else
			{
							echo '<script type="text/javascript"> alert("Invalid Credentials") </script>';
			}
		}	 
	?>
	</div>
</body>
</html>