<?php
	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Register page</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#bdc3c7">

<div id="main-wrapper">
     <center>
	     <p id=h1><h2>S i g n &nbsp Up &nbsp F o r m</h2></p>
		 <img src="imgs/sa.png" class="avatar"/>
	</center>
	
	<form class="myform" action="register.php" method="post">
	     <label><b>U s e r n a m e :</b></label><br><br>
		 <input name="username" type="text"  class="inputvalues" placeholder="E n t e r   U s e r n a m e" required/><br><br>
		 <label><b>P a s s w o r d :</b></label><br><br>
		 <input name="password" type="password"  class="inputvalues" placeholder="E n t e r  N e w  P a s s w o r d"required/><br><br>
		 <label><b> C o n f i r m &nbsp P a s s w o r d :</b></label><br><br>
		 <input name="cpassword" type="password"  class="inputvalues" placeholder="C o n f i r m  P a s s w o r d"required/><br><br>
		 <h4><center><input name="submit_btn" type="submit" id="signup_btn" value=" S i g n   U p"/><br>
		 <a href="index.php"><input type="button" id="back_btn" value="<- B a c k  t o  L o g i n"/></a></center><h4>
	 </form>
	 <?php
		
		if(isset($_POST['submit_btn']))
		{
			//echo '<script type="text/javascript"> alert("Sign Up button clicked") </script>';
			$username = $_POST['username'];
			$password = $_POST['password'];
			$cpassword = $_POST['cpassword'];
			
			if($password==$cpassword)
			{	
				$query= "select * from user WHERE username='$username'";
					$query_run = mysqli_query($con,$query);
				
				
				if(mysqli_num_rows($query_run)>0)
				{
					// there is already a user with same username.
					echo '<script type="text/javascript"> alert("Username already exists... Try another username") </script>';
				}
				else
				{
					$query= "insert into user values('$username','$password')";
					$query_run = mysqli_query($con,$query);
					
					if($query_run)
					{
						echo '<script type="text/javascript"> alert("User Registered ... Go to login page") </script>';
					}
					else
					{
							echo '<script type="text/javascript"> alert("Error !") </script>';
					}
				}
			}
			else
			{
				echo '<script type="text/javascript"> alert("Password doesnt match") </script>';
			}
			
			
		}
	 ?>
	</div>
</body>
</html>